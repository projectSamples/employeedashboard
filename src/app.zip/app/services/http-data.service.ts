import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {IProject} from './employee-data.service';

@Injectable({
  providedIn: 'root'
})
export class HttpDataService {

  countryUrl = 'assets/project-list.json';
  employeeUrl = 'assets/employee-list.json';

  constructor(private http: HttpClient) { }

  getCountryData(): Observable<any> {
    return this.http.get(this.countryUrl);
  }

  getEmployeeData(): Observable<any> {
    return this.http.get(this.employeeUrl);
  }
}
